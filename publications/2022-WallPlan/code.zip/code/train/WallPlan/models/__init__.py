from .basic import ParallelModule
from .net import model