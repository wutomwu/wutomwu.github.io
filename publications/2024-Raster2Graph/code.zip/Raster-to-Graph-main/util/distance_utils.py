def distance(pos1, pos2):
    return abs(pos1[0].item() - pos2[0].item()), abs(pos1[1].item() - pos2[1].item())

