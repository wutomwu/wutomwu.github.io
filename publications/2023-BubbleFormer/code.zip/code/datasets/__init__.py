
from .RPLAN_GRAPH_DATASET import build_RG_dataset



def build_dataset(image_set, args):
    return build_RG_dataset(image_set, args)
