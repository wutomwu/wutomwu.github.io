#!/bin/bash

/usr/bin/python3 generate.py --step 50 --generate_method generate_based_on_bdr_json --model_path /data1/fjx/bdr-models/model8/model/epoch=1999.ckpt --output_path /data1/fjx/bdr-models/model8/output_target/output --bdr_path /home/fjx/bdr --json_path /home/fjx/bdr62/nsample.json 